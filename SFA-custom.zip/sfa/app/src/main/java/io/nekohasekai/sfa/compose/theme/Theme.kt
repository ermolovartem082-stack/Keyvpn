package io.nekohasekai.sfa.compose.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.core.view.WindowCompat

private val Ink = Color(0xFF0B0B0B)

// Минимализм: белый фон, чёрные акценты, одна светлая серая поверхность для карточек
private val KeyColorScheme =
    lightColorScheme(
        primary = Ink,
        onPrimary = Color.White,
        primaryContainer = Ink,
        onPrimaryContainer = Color.White,
        secondary = Color(0xFF3A3A3A),
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFEDEDEA),
        onSecondaryContainer = Ink,
        tertiary = Color(0xFF00C781),
        background = Color.White,
        onBackground = Ink,
        surface = Color.White,
        onSurface = Ink,
        surfaceVariant = Color(0xFFF1F1EE),
        onSurfaceVariant = Color(0xFF55554F),
        surfaceContainerLowest = Color.White,
        surfaceContainerLow = Color(0xFFF8F8F6),
        surfaceContainer = Color(0xFFF3F3F0),
        surfaceContainerHigh = Color(0xFFEDEDEA),
        surfaceContainerHighest = Color(0xFFE7E7E3),
        outline = Color(0xFF8B8B85),
        outlineVariant = Color(0xFFD9D9D4),
    )

// Жирные заголовки (Roboto Black / ExtraBold)
private val BoldTypography =
    Typography.copy(
        headlineLarge = Typography.headlineLarge.copy(fontWeight = FontWeight.Black),
        headlineMedium = Typography.headlineMedium.copy(fontWeight = FontWeight.Black),
        headlineSmall = Typography.headlineSmall.copy(fontWeight = FontWeight.Black),
        titleLarge = Typography.titleLarge.copy(fontWeight = FontWeight.Black),
        titleMedium = Typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
        titleSmall = Typography.titleSmall.copy(fontWeight = FontWeight.ExtraBold),
        labelLarge = Typography.labelLarge.copy(fontWeight = FontWeight.ExtraBold),
    )

@Composable
fun Theme(
    // Параметры оставлены для совместимости с вызовами: тема теперь всегда светлая
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = true
                isAppearanceLightNavigationBars = true
            }
        }
    }

    MaterialTheme(
        colorScheme = KeyColorScheme,
        typography = BoldTypography,
        shapes = Shapes,
        content = content,
    )
}
