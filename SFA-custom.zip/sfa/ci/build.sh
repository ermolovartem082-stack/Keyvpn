#!/usr/bin/env bash
# Сборка в GitHub Actions: ядро sing-box (libbox.aar) + APK. Запускается из корня репозитория.
set -euxo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
VER=$(grep '^VERSION_NAME=' version.properties | cut -d= -f2)
GOV=$(grep '^GO_VERSION=' version.properties | cut -d= -f2)
TMP="${RUNNER_TEMP:-/tmp}"

export JAVA_HOME="${JAVA_HOME_17_X64:-$JAVA_HOME}"
export PATH="$JAVA_HOME/bin:$PATH"

# Go нужной версии
curl -fsSL "https://go.dev/dl/${GOV}.linux-amd64.tar.gz" | tar -C "$TMP" -xzf -
export PATH="$TMP/go/bin:$HOME/go/bin:$PATH"
go version

# Android SDK/NDK
yes | sdkmanager --licenses > /dev/null || true
sdkmanager --install "ndk;28.0.13004108"
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/28.0.13004108"

# Ядро sing-box той же версии, что и приложение
git clone --depth 1 --branch "v${VER}" https://github.com/SagerNet/sing-box.git "$TMP/sing-box"
(cd "$TMP/sing-box" && make lib_install && make lib_android)
mkdir -p "$ROOT/app/libs"
find "$TMP" -maxdepth 4 -name 'libbox*.aar' -exec cp -v {} "$ROOT/app/libs/" \;
test -f "$ROOT/app/libs/libbox.aar"

# Приложение
chmod +x ./gradlew
./gradlew --no-daemon :app:assembleOtherDebug
