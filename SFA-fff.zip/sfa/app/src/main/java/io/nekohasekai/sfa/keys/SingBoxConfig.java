package io.nekohasekai.sfa.keys;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Превращает ключ любого поддерживаемого типа в конфиг sing-box (tun-режим для Android). */
public class SingBoxConfig {
    static final class L {
        String scheme = "", user = "", host = "", frag = "";
        int port = 443;
        final Map<String, String> q = new HashMap<>();
    }

    static Map<String, Object> o(Object... kv) {
        Map<String, Object> m = Json.map();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put((String) kv[i], kv[i + 1]);
        return m;
    }

    static List<Object> list(Object... v) { return new ArrayList<>(Arrays.asList(v)); }

    static L link(String s) {
        L l = new L();
        int i = s.indexOf("://");
        l.scheme = s.substring(0, i).toLowerCase(Locale.ROOT);
        String r = s.substring(i + 3);
        int h = r.indexOf('#');
        if (h >= 0) { l.frag = KeyParser.dec(r.substring(h + 1)); r = r.substring(0, h); }
        int qi = r.indexOf('?');
        String qs = "";
        if (qi >= 0) { qs = r.substring(qi + 1); r = r.substring(0, qi); }
        for (String kv : qs.split("&")) {
            int e = kv.indexOf('=');
            if (e > 0) l.q.put(kv.substring(0, e).toLowerCase(Locale.ROOT), KeyParser.dec(kv.substring(e + 1)));
        }
        int sl = r.indexOf('/');
        if (sl >= 0) r = r.substring(0, sl);
        int at = r.lastIndexOf('@');
        String hp = r;
        if (at >= 0) { l.user = r.substring(0, at); hp = r.substring(at + 1); }
        if (hp.startsWith("[")) {
            int j = hp.indexOf(']');
            l.host = hp.substring(1, j);
            String p = hp.substring(j + 1);
            if (p.startsWith(":")) l.port = Integer.parseInt(p.substring(1));
        } else {
            int c = hp.lastIndexOf(':');
            if (c >= 0) { l.host = hp.substring(0, c); l.port = Integer.parseInt(hp.substring(c + 1)); }
            else l.host = hp;
        }
        return l;
    }

    static String q(L l, String k, String d) {
        String v = l.q.get(k);
        return v == null || v.isEmpty() ? d : v;
    }

    static boolean truthy(String v) { return "1".equals(v) || "true".equalsIgnoreCase(v); }

    static boolean isIp(String h) { return h.matches("[0-9.]+") || h.contains(":"); }

    static String jv(String json, String key) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*(?:\"((?:[^\"\\\\]|\\\\.)*)\"|([^,}\\s]+))").matcher(json);
        if (!m.find()) return "";
        return m.group(1) != null ? m.group(1) : m.group(2);
    }

    static Map<String, Object> tls(L l, boolean reality, String sniDefault) {
        Map<String, Object> t = o("enabled", true);
        String sni = q(l, "sni", q(l, "peer", q(l, "host", sniDefault)));
        if (!sni.isEmpty() && !isIp(sni)) t.put("server_name", sni);
        if (truthy(q(l, "allowinsecure", q(l, "insecure", "")))) t.put("insecure", true);
        String alpn = q(l, "alpn", "");
        if (!alpn.isEmpty()) t.put("alpn", new ArrayList<Object>(Arrays.asList(alpn.split(","))));
        String fp = q(l, "fp", "");
        if (reality) {
            if (fp.isEmpty()) fp = "chrome";
            t.put("reality", o("enabled", true, "public_key", q(l, "pbk", ""), "short_id", q(l, "sid", "")));
        }
        if (!fp.isEmpty() && !fp.equals("none")) t.put("utls", o("enabled", true, "fingerprint", fp));
        return t;
    }

    static Map<String, Object> transport(String net, String host, String path, String service) {
        net = net == null ? "tcp" : net.toLowerCase(Locale.ROOT);
        switch (net) {
            case "ws": {
                Map<String, Object> m = o("type", "ws", "path", path.isEmpty() ? "/" : path);
                if (!host.isEmpty()) m.put("headers", o("Host", host));
                return m;
            }
            case "grpc":
                return o("type", "grpc", "service_name", service);
            case "http":
            case "h2": {
                Map<String, Object> m = o("type", "http", "path", path.isEmpty() ? "/" : path);
                if (!host.isEmpty()) m.put("host", list((Object[]) host.split(",")));
                return m;
            }
            case "httpupgrade": {
                Map<String, Object> m = o("type", "httpupgrade", "path", path.isEmpty() ? "/" : path);
                if (!host.isEmpty()) m.put("host", host);
                return m;
            }
            default:
                return null;
        }
    }

    static Map<String, Object> vless(L l) {
        Map<String, Object> m = o("type", "vless", "tag", "proxy", "server", l.host, "server_port", l.port,
                "uuid", l.user, "packet_encoding", "xudp");
        String flow = q(l, "flow", "");
        if (!flow.isEmpty()) m.put("flow", flow);
        String sec = q(l, "security", "none");
        if (sec.equals("tls") || sec.equals("reality")) m.put("tls", tls(l, sec.equals("reality"), l.host));
        Map<String, Object> tr = transport(q(l, "type", "tcp"), q(l, "host", ""), q(l, "path", ""), q(l, "servicename", ""));
        if (tr != null) m.put("transport", tr);
        return m;
    }

    static Map<String, Object> vmess(String raw) {
        String j = KeyParser.b64(body(raw));
        if (j == null) throw new IllegalArgumentException("Неверный vmess-ключ");
        String add = jv(j, "add"), port = jv(j, "port"), net = jv(j, "net"), host = jv(j, "host"), path = jv(j, "path");
        String scy = jv(j, "scy"), aid = jv(j, "aid"), sni = jv(j, "sni"), fp = jv(j, "fp"), alpn = jv(j, "alpn");
        Map<String, Object> m = o("type", "vmess", "tag", "proxy", "server", add, "server_port", Integer.parseInt(port.isEmpty() ? "443" : port),
                "uuid", jv(j, "id"), "security", scy.isEmpty() ? "auto" : scy,
                "alter_id", aid.isEmpty() ? 0 : Integer.parseInt(aid));
        if (jv(j, "tls").equals("tls")) {
            Map<String, Object> t = o("enabled", true);
            String name = !sni.isEmpty() ? sni : (!host.isEmpty() ? host : add);
            if (!isIp(name)) t.put("server_name", name);
            if (!alpn.isEmpty()) t.put("alpn", new ArrayList<Object>(Arrays.asList(alpn.split(","))));
            if (!fp.isEmpty()) t.put("utls", o("enabled", true, "fingerprint", fp));
            m.put("tls", t);
        }
        Map<String, Object> tr = transport(net.isEmpty() ? "tcp" : net, host, path, path);
        if (tr != null) m.put("transport", tr);
        return m;
    }

    static Map<String, Object> trojan(L l) {
        Map<String, Object> m = o("type", "trojan", "tag", "proxy", "server", l.host, "server_port", l.port,
                "password", KeyParser.dec(l.user));
        if (!q(l, "security", "tls").equals("none")) m.put("tls", tls(l, false, l.host));
        Map<String, Object> tr = transport(q(l, "type", "tcp"), q(l, "host", ""), q(l, "path", ""), q(l, "servicename", ""));
        if (tr != null) m.put("transport", tr);
        return m;
    }

    static String ssNormalize(String raw) {
        if (raw.contains("@")) return raw;
        int i = raw.indexOf("://");
        String rest = raw.substring(i + 3), frag = "";
        int h = rest.indexOf('#');
        if (h >= 0) { frag = rest.substring(h); rest = rest.substring(0, h); }
        int qi = rest.indexOf('?');
        if (qi >= 0) rest = rest.substring(0, qi);
        String d = KeyParser.b64(rest);
        return d != null && d.contains("@") ? "ss://" + d + frag : raw;
    }

    static Map<String, Object> ss(L l) {
        String mp;
        if (l.user.contains(":")) mp = KeyParser.dec(l.user);
        else {
            String d = KeyParser.b64(KeyParser.dec(l.user));
            mp = d == null ? "" : d;
        }
        int c = mp.indexOf(':');
        if (c < 0) throw new IllegalArgumentException("Неверный ss-ключ");
        Map<String, Object> m = o("type", "shadowsocks", "tag", "proxy", "server", l.host, "server_port", l.port,
                "method", mp.substring(0, c), "password", mp.substring(c + 1));
        String plugin = q(l, "plugin", "");
        if (!plugin.isEmpty()) {
            String[] p = plugin.split(";", 2);
            m.put("plugin", p[0].equals("simple-obfs") ? "obfs-local" : p[0]);
            if (p.length > 1) m.put("plugin_opts", p[1]);
        }
        return m;
    }

    static Map<String, Object> hy2(L l) {
        Map<String, Object> m = o("type", "hysteria2", "tag", "proxy", "server", l.host, "server_port", l.port,
                "password", KeyParser.dec(l.user));
        Map<String, Object> t = tls(l, false, l.host);
        t.remove("utls");
        if (!t.containsKey("alpn")) t.put("alpn", list("h3"));
        m.put("tls", t);
        if (q(l, "obfs", "").equals("salamander"))
            m.put("obfs", o("type", "salamander", "password", q(l, "obfs-password", "")));
        return m;
    }

    static Map<String, Object> tuic(L l) {
        String u = KeyParser.dec(l.user);
        int c = u.indexOf(':');
        Map<String, Object> m = o("type", "tuic", "tag", "proxy", "server", l.host, "server_port", l.port,
                "uuid", c < 0 ? u : u.substring(0, c), "password", c < 0 ? "" : u.substring(c + 1),
                "congestion_control", q(l, "congestion_control", "bbr"),
                "udp_relay_mode", q(l, "udp_relay_mode", "native"));
        Map<String, Object> t = tls(l, false, l.host);
        t.remove("utls");
        if (!t.containsKey("alpn")) t.put("alpn", list("h3"));
        m.put("tls", t);
        return m;
    }

    static Map<String, Object> socks(L l) {
        String u = l.user.contains(":") ? KeyParser.dec(l.user) : (l.user.isEmpty() ? "" : String.valueOf(KeyParser.b64(KeyParser.dec(l.user))));
        int c = u.indexOf(':');
        Map<String, Object> m = o("type", "socks", "tag", "proxy", "server", l.host, "server_port", l.port, "version", "5");
        if (c > 0) { m.put("username", u.substring(0, c)); m.put("password", u.substring(c + 1)); }
        return m;
    }

    static String[] hostPort(String ep) {
        ep = ep.trim();
        if (ep.startsWith("[")) {
            int j = ep.indexOf(']');
            return new String[]{ep.substring(1, j), ep.substring(j + 2)};
        }
        int c = ep.lastIndexOf(':');
        return new String[]{ep.substring(0, c), ep.substring(c + 1)};
    }

    static Map<String, Object> wg(String conf) {
        Map<String, String> ifc = new HashMap<>(), peer = new HashMap<>(), cur = null;
        for (String line : conf.split("\\r?\\n")) {
            String t = line.trim();
            if (t.isEmpty() || t.startsWith("#") || t.startsWith(";")) continue;
            if (t.equalsIgnoreCase("[Interface]")) { cur = ifc; continue; }
            if (t.equalsIgnoreCase("[Peer]")) { cur = peer.isEmpty() ? peer : new HashMap<String, String>(); continue; }
            int e = t.indexOf('=');
            if (e < 0 || cur == null) continue;
            cur.put(t.substring(0, e).trim().toLowerCase(Locale.ROOT), t.substring(e + 1).trim());
        }
        String ep = peer.get("endpoint");
        if (ep == null || ifc.get("privatekey") == null || peer.get("publickey") == null)
            throw new IllegalArgumentException("В WireGuard-ключе не хватает PrivateKey, PublicKey или Endpoint");
        String[] hp = hostPort(ep);
        List<Object> addrs = new ArrayList<>();
        String ad = ifc.get("address");
        if (ad != null) for (String a : ad.split(",")) if (!a.trim().isEmpty()) addrs.add(a.trim());
        Map<String, Object> m = o("type", "wireguard", "tag", "proxy", "server", hp[0], "server_port", Integer.parseInt(hp[1]),
                "local_address", addrs, "private_key", ifc.get("privatekey"), "peer_public_key", peer.get("publickey"));
        if (peer.containsKey("presharedkey")) m.put("pre_shared_key", peer.get("presharedkey"));
        if (ifc.containsKey("mtu")) m.put("mtu", Integer.parseInt(ifc.get("mtu")));
        String res = peer.containsKey("reserved") ? peer.get("reserved") : ifc.get("reserved");
        if (res != null) {
            List<Object> r = new ArrayList<>();
            for (String x : res.split(",")) r.add(Integer.parseInt(x.trim()));
            m.put("reserved", r);
        }
        return m;
    }

    static String body(String raw) { return raw.substring(raw.indexOf("://") + 3).split("#")[0]; }

    static Map<String, Object> outbound(String type, String raw) {
        switch (type) {
            case "VLESS": return vless(link(raw));
            case "VMESS": return vmess(raw);
            case "TROJAN": return trojan(link(raw));
            case "SS": return ss(link(ssNormalize(raw)));
            case "HY2": return hy2(link(raw));
            case "TUIC": return tuic(link(raw));
            case "SOCKS": return socks(link(raw));
            case "WG": return wg(raw);
            default: throw new IllegalArgumentException("Тип " + type + " пока не поддерживается");
        }
    }

    /** WireGuard в формате sing-box 1.11+: endpoint вместо outbound. */
    static Map<String, Object> wgEndpoint(String conf) {
        Map<String, Object> w = wg(conf);
        Map<String, Object> peer = o("address", w.get("server"), "port", w.get("server_port"),
                "public_key", w.get("peer_public_key"), "allowed_ips", list("0.0.0.0/0", "::/0"));
        if (w.containsKey("pre_shared_key")) peer.put("pre_shared_key", w.get("pre_shared_key"));
        if (w.containsKey("reserved")) peer.put("reserved", w.get("reserved"));
        Map<String, Object> e = o("type", "wireguard", "tag", "wg", "address", w.get("local_address"),
                "private_key", w.get("private_key"), "peers", list(peer));
        if (w.containsKey("mtu")) e.put("mtu", w.get("mtu"));
        return e;
    }

    /** Полный профиль: все серверы, группа auto (urltest, показывает пинг в панели) и selector proxy. */
    public static String buildProfile(List<KeyParser.Key> keys) {
        List<Object> outbounds = new ArrayList<>(), endpoints = new ArrayList<>(), tags = new ArrayList<>();
        Set<String> used = new HashSet<>(Arrays.asList("direct", "auto", "proxy", "dns-remote", "dns-local", "tun-in"));
        for (KeyParser.Key k : keys) {
            String base = k.name == null || k.name.isEmpty() ? k.host : k.name;
            String tag = base;
            int i = 2;
            while (!used.add(tag)) tag = base + " #" + (i++);
            try {
                if (k.type.equals("WG")) {
                    Map<String, Object> e = wgEndpoint(k.raw);
                    e.put("tag", tag);
                    endpoints.add(e);
                } else {
                    Map<String, Object> m = outbound(k.type, k.raw);
                    m.put("tag", tag);
                    outbounds.add(m);
                }
                tags.add(tag);
            } catch (RuntimeException e) {
                used.remove(tag);
            }
        }
        if (tags.isEmpty())
            throw new IllegalArgumentException("Нет поддерживаемых ключей (Hysteria v1 и SSR не поддерживаются)");
        outbounds.add(o("type", "urltest", "tag", "auto", "outbounds", new ArrayList<Object>(tags),
                "url", "https://www.gstatic.com/generate_204", "interval", "3m", "tolerance", 50));
        List<Object> sel = new ArrayList<>();
        sel.add("auto");
        sel.addAll(tags);
        outbounds.add(o("type", "selector", "tag", "proxy", "outbounds", sel, "default", "auto"));
        outbounds.add(o("type", "direct", "tag", "direct"));
        Map<String, Object> cfg = o(
                "log", o("level", "warn", "timestamp", true),
                "dns", o("servers", list(
                                o("type", "tls", "tag", "dns-remote", "server", "8.8.8.8", "detour", "proxy"),
                                o("type", "local", "tag", "dns-local")),
                        "final", "dns-remote", "strategy", "ipv4_only"),
                "inbounds", list(o("type", "tun", "tag", "tun-in",
                        "address", list("172.19.0.1/30", "fdfe:dcba:9876::1/126"), "auto_route", true)),
                "outbounds", outbounds);
        if (!endpoints.isEmpty()) cfg.put("endpoints", endpoints);
        cfg.put("route", o("rules", list(
                        o("action", "sniff"),
                        o("protocol", "dns", "action", "hijack-dns"),
                        o("ip_is_private", true, "action", "route", "outbound", "direct")),
                "final", "proxy", "auto_detect_interface", true, "default_domain_resolver", "dns-local"));
        return Json.write(cfg);
    }
}
