package io.nekohasekai.sfa.compose.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.nekohasekai.sfa.Application

/**
 * Переключатель тёмной/светлой темы. Значение хранится в SharedPreferences.
 */
object ThemeState {
    private const val PREFS = "gamma_theme"
    private const val KEY_DARK = "dark"

    private fun prefs() = Application.application.getSharedPreferences(PREFS, 0)

    var isDark by mutableStateOf(prefs().getBoolean(KEY_DARK, false))
        private set

    fun toggle() {
        isDark = !isDark
        prefs().edit().putBoolean(KEY_DARK, isDark).apply()
    }
}
