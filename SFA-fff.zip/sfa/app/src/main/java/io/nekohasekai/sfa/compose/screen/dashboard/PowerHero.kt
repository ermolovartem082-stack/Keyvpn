package io.nekohasekai.sfa.compose.screen.dashboard

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import io.nekohasekai.sfa.constant.Status
import kotlinx.coroutines.delay

/**
 * Большая кнопка запуска: в выключенном состоянии значок питания,
 * при подключении плавно превращается в «паузу» (две палки), под ней таймер работы.
 * Сверху справа переключатель тёмной/светлой темы.
 */
@Composable
fun PowerHero(
    status: Status,
    hasProfile: Boolean,
    startTime: Long?,
    darkTheme: Boolean,
    onPower: () -> Unit,
    onPasteKey: () -> Unit,
    onToggleTheme: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val isOn = status != Status.Stopped

    // Кнопка чёрная, значки всегда белые, обводка серая и при подключении становится ярче.
    val buttonColor = Color.Black
    val iconColor = Color.White
    val ringColor by animateColorAsState(
        targetValue = if (isOn) Color(0xFFD0D0D0) else Color(0xFF555555),
        animationSpec = tween(500),
        label = "ringBrightness",
    )

    val label = when (status) {
        Status.Started -> "Подключено"
        Status.Starting -> "Подключение…"
        Status.Stopping -> "Отключение…"
        else -> if (hasProfile) "Нажмите для подключения" else "Сначала добавьте ключ"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 4.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            IconButton(onClick = onToggleTheme) {
                Icon(
                    imageVector = if (darkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                    contentDescription = if (darkTheme) "Светлая тема" else "Тёмная тема",
                )
            }
        }

        Box(
            modifier = Modifier.size(208.dp),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .clip(CircleShape)
                    .background(buttonColor)
                    .border(BorderStroke(6.dp, ringColor), CircleShape)
                    .clickable(enabled = status != Status.Stopping, onClick = onPower),
                contentAlignment = Alignment.Center,
            ) {
                Crossfade(targetState = isOn, animationSpec = tween(400), label = "powerToPause") { on ->
                    if (on) {
                        PauseGlyph(color = iconColor)
                    } else {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = label,
                            tint = iconColor,
                            modifier = Modifier.size(88.dp),
                        )
                    }
                }
            }
        }

        if (status == Status.Started && startTime != null) {
            ConnectionTimer(startTime = startTime)
        }
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
        )
        OutlinedButton(onClick = onPasteKey) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
            Text(text = "  Вставить ключ")
        }
    }
}

/** Две вертикальные палки посередине, как значок паузы (цвет задаёт вызывающий). */
@Composable
private fun PauseGlyph(color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        repeat(2) {
            Box(
                modifier = Modifier
                    .size(width = 22.dp, height = 74.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(color),
            )
        }
    }
}

/** Таймер работы подключения ЧЧ:ММ:СС. */
@Composable
private fun ConnectionTimer(startTime: Long) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(startTime) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val total = ((now - startTime) / 1000).coerceAtLeast(0)
    Text(
        text = String.format("%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60),
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Black,
    )
}
