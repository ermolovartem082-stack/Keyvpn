package io.nekohasekai.sfa.keys;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Разбор ключей: WireGuard, vless, vmess, trojan, ss, hy2, tuic, socks, подписки, ссылки Happ и обёртки других клиентов. */
public class KeyParser {
    public static class Key {
        public String name = "", type = "", raw = "", host = "";
    }

    static final Set<String> WRAP = new HashSet<>(Arrays.asList(
            "v2rayng", "clash", "clashmeta", "sing-box", "hiddify", "v2box", "streisand", "nekobox", "karing"));
    static final Pattern URLP = Pattern.compile("[?&]url=([^&#]+)");

    static String dec(String s) {
        try { return URLDecoder.decode(s.replace("+", "%2B"), "UTF-8"); } catch (Exception e) { return s; }
    }

    /** Свой декодер base64: java.util.Base64 есть только с Android 8, а minSdk приложения ниже. */
    static String b64(String s) {
        String in = s.replaceAll("\\s+", "").replace('-', '+').replace('_', '/');
        while (in.endsWith("=")) in = in.substring(0, in.length() - 1);
        if (in.isEmpty()) return null;
        String abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        int buf = 0, bits = 0;
        for (int i = 0; i < in.length(); i++) {
            int v = abc.indexOf(in.charAt(i));
            if (v < 0) return null;
            buf = (buf << 6) | v;
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                out.write((buf >> bits) & 0xFF);
            }
        }
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    static String label(String scheme) {
        switch (scheme) {
            case "vless": return "VLESS";
            case "trojan": return "TROJAN";
            case "ss": return "SS";
            case "ssr": return "SSR";
            case "hysteria2": case "hy2": return "HY2";
            case "hysteria": return "HY";
            case "tuic": return "TUIC";
            case "socks": case "socks5": return "SOCKS";
            default: return null;
        }
    }

    static String frag(String s) {
        int h = s.indexOf('#');
        return h < 0 ? "" : dec(s.substring(h + 1)).trim();
    }

    static String hostOf(String s) {
        int i = s.indexOf("://");
        if (i < 0) return "";
        String a = s.substring(i + 3);
        int e = a.length();
        for (char c : new char[]{'/', '?', '#'}) {
            int j = a.indexOf(c);
            if (j >= 0 && j < e) e = j;
        }
        a = a.substring(0, e);
        int at = a.lastIndexOf('@');
        if (at >= 0) a = a.substring(at + 1);
        if (a.startsWith("[")) {
            int j = a.indexOf(']');
            return j > 0 ? a.substring(1, j) : a;
        }
        int c = a.lastIndexOf(':');
        if (c >= 0) a = a.substring(0, c);
        return a;
    }

    static String jstr(String json, String key) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json);
        if (!m.find()) return "";
        String v = m.group(1);
        Matcher u = Pattern.compile("\\\\u([0-9a-fA-F]{4})").matcher(v);
        StringBuffer sb = new StringBuffer();
        while (u.find()) u.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf((char) Integer.parseInt(u.group(1), 16))));
        u.appendTail(sb);
        return sb.toString().replace("\\\"", "\"").replace("\\/", "/");
    }

    static String unwrap(String s) {
        String l = s.toLowerCase(Locale.ROOT);
        if (l.startsWith("happ://add/")) return s.substring("happ://add/".length());
        if (l.startsWith("sub://")) {
            String d = b64(s.substring(6));
            if (d != null && d.contains("://")) return d.trim();
        }
        int i = l.indexOf("://");
        if (i > 0 && WRAP.contains(l.substring(0, i))) {
            Matcher m = URLP.matcher(s);
            if (m.find()) return dec(m.group(1));
        }
        return s;
    }

    static Key wg(String conf) {
        Key k = new Key();
        k.type = "WG";
        k.raw = conf.trim();
        Matcher m = Pattern.compile("(?im)^\\s*Endpoint\\s*=\\s*(.+?)\\s*$").matcher(conf);
        String host = m.find() ? m.group(1) : "";
        int c = host.lastIndexOf(':');
        if (c > 0 && !host.endsWith("]")) host = host.substring(0, c);
        k.host = host.replace("[", "").replace("]", "");
        Matcher nm = Pattern.compile("(?m)^\\s*#\\s*(?:Name\\s*[=:]\\s*)?(.+)$").matcher(conf);
        k.name = nm.find() ? nm.group(1).trim() : (k.host.isEmpty() ? "WireGuard" : k.host);
        return k;
    }

    /** wireguard://PRIVATEKEY@host:port?publickey=...&address=... → обычный конфиг */
    static String wgUri(String s) {
        String a = s.substring(s.indexOf("://") + 3);
        int h = a.indexOf('#');
        if (h >= 0) a = a.substring(0, h);
        String q = "";
        int qi = a.indexOf('?');
        if (qi >= 0) { q = a.substring(qi + 1); a = a.substring(0, qi); }
        int at = a.lastIndexOf('@');
        if (at < 0) return null;
        String priv = dec(a.substring(0, at)), ep = a.substring(at + 1);
        Map<String, String> p = new HashMap<>();
        for (String kv : q.split("&")) {
            int e = kv.indexOf('=');
            if (e > 0) p.put(kv.substring(0, e).toLowerCase(Locale.ROOT), dec(kv.substring(e + 1)));
        }
        String pub = p.get("publickey"), addr = p.get("address");
        if (pub == null || addr == null || ep.isEmpty()) return null;
        StringBuilder b = new StringBuilder("[Interface]\nPrivateKey = " + priv + "\nAddress = " + addr + "\n");
        b.append("DNS = ").append(p.getOrDefault("dns", "1.1.1.1")).append('\n');
        if (p.containsKey("mtu")) b.append("MTU = ").append(p.get("mtu")).append('\n');
        b.append("\n[Peer]\nPublicKey = ").append(pub).append('\n');
        if (p.containsKey("presharedkey")) b.append("PresharedKey = ").append(p.get("presharedkey")).append('\n');
        b.append("AllowedIPs = ").append(p.getOrDefault("allowedips", "0.0.0.0/0, ::/0")).append('\n');
        b.append("Endpoint = ").append(ep).append('\n');
        b.append("PersistentKeepalive = ").append(p.getOrDefault("keepalive", "25")).append('\n');
        return b.toString();
    }

    static Key one(String s0) {
        String s = unwrap(s0.trim());
        int i = s.indexOf("://");
        if (i <= 0) return null;
        String scheme = s.substring(0, i).toLowerCase(Locale.ROOT);
        Key k = new Key();
        k.raw = s;
        switch (scheme) {
            case "http":
            case "https":
                k.type = "SUB"; k.host = hostOf(s); k.name = k.host;
                return k;
            case "happ":
                k.type = "CRYPT"; k.name = "Happ";
                return k;
            case "vmess": {
                String j = b64(s.substring(i + 3).split("#")[0]);
                if (j == null || !j.contains("{")) return null;
                k.type = "VMESS"; k.host = jstr(j, "add"); k.name = jstr(j, "ps");
                if (k.host.isEmpty()) return null;
                break;
            }
            case "wireguard": {
                String conf = wgUri(s);
                if (conf == null) return null;
                Key w = wg(conf);
                String f = frag(s);
                if (!f.isEmpty()) w.name = f;
                return w;
            }
            default: {
                String type = label(scheme);
                if (type == null) return null;
                k.type = type;
                k.host = hostOf(s);
                if (scheme.equals("ss") && !s.contains("@")) {
                    String d = b64(s.substring(i + 3).split("#")[0]);
                    if (d != null && d.contains("@")) k.host = hostOf("ss://" + d);
                }
                if (k.host.isEmpty()) return null;
                k.name = frag(s);
            }
        }
        if (k.name == null || k.name.isEmpty()) k.name = k.host;
        return k;
    }

    /** Разбирает вставленный текст (один ключ, список, base64-список, WG-конфиг). Подписки приходят как type "SUB". */
    public static List<Key> parse(String text) {
        List<Key> out = new ArrayList<>();
        if (text == null) return out;
        String t = text.trim();
        if (t.isEmpty()) return out;
        if (t.contains("[Interface]")) {
            out.add(wg(t));
            return out;
        }
        if (!t.contains("://")) {
            String d = b64(t);
            if (d != null && d.contains("://")) t = d;
        }
        for (String line : t.split("[\\r\\n]+")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            Key k = one(line);
            if (k != null) out.add(k);
        }
        return out;
    }

    public static String fetch(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "KeyVPN/1.0");
        if (c.getResponseCode() / 100 != 2) throw new IOException("HTTP " + c.getResponseCode());
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && b.size() < 2000000) b.write(buf, 0, n);
            return b.toString("UTF-8");
        }
    }
}
