package io.nekohasekai.sfa.compose.screen.keys

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import io.nekohasekai.sfa.compose.screen.configuration.ProfileImportHandler
import kotlinx.coroutines.launch

@Composable
fun PasteKeyDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Добавить ключ") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = {
                        text = it
                        error = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    placeholder = { Text("vless:// vmess:// trojan:// ss:// hy2:// tuic://, ссылка подписки или Happ") },
                    isError = error != null,
                )
                val message = error
                if (message != null) {
                    Text(
                        text = message,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
                TextButton(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = cm.primaryClip
                        if (clip != null && clip.itemCount > 0) {
                            text = clip.getItemAt(0).coerceToText(context).toString()
                            error = null
                        }
                    },
                ) { Text("Вставить из буфера") }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy && text.isNotBlank(),
                onClick = {
                    busy = true
                    scope.launch {
                        val result = ProfileImportHandler(context).importKeyText(text)
                        busy = false
                        when (result) {
                            is ProfileImportHandler.ImportResult.Success -> {
                                Toast.makeText(context, "Добавлено: ${result.profile.name}", Toast.LENGTH_SHORT).show()
                                onDismiss()
                            }
                            is ProfileImportHandler.ImportResult.Error -> error = result.message
                        }
                    }
                },
            ) { Text(if (busy) "Загрузка…" else "Добавить") }
        },
        dismissButton = {
            TextButton(enabled = !busy, onClick = onDismiss) { Text("Отмена") }
        },
    )
}
