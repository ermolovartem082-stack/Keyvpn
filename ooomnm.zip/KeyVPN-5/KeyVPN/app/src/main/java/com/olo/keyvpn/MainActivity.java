package com.olo.keyvpn;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int BG = 0xFFF3F3F0, INK = 0xFF0B0B0B, MUTED = 0xFF8B8B85, CARD = 0xFFFFFFFF, GREEN = 0xFF00C781,
            AMBER = 0xFFF5A623, RED = 0xFFE5484D;
    static final String BLACK = "sans-serif-black", MED = "sans-serif-medium";
    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT, WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    SharedPreferences sp;
    JSONArray keys = new JSONArray();
    int sel = 0, uiState = ConnectButton.OFF, tickCount = 0;
    boolean wantOn = false;
    long startedAt = 0, since = 0;
    String pendingCfg = "";
    ConnectButton cb;
    TextView tvState, sub, pingView, timer, listLabel, btnAdd;
    LinearLayout list, addPanel;
    EditText etIn;
    final Map<String, Integer> pings = new HashMap<>();
    final ExecutorService pool = Executors.newFixedThreadPool(6);
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable tick = new Runnable() {
        public void run() {
            sync();
            if (uiState == ConnectButton.ON && since > 0) {
                long s = (SystemClock.elapsedRealtime() - since) / 1000;
                timer.setText(String.format("%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60));
            }
            if (++tickCount % 10 == 0 && uiState == ConnectButton.ON) pingSelected();
            h.postDelayed(this, 500);
        }
    };

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    GradientDrawable rr(int color, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    TextView tv(String s, int size, int color, String font) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(font, Typeface.NORMAL));
        return t;
    }

    LinearLayout.LayoutParams lp(int w, int hh, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, hh);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    static int pingColor(int ms) { return ms < 0 ? MUTED : ms < 150 ? GREEN : ms < 400 ? AMBER : RED; }

    static String pingShort(int ms) { return ms == -2 ? "UDP" : ms < 0 ? "×" : ms + " ms"; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("k", MODE_PRIVATE);
        sel = sp.getInt("sel", 0);
        try { keys = new JSONArray(sp.getString("keys", "[]")); } catch (Exception e) { }
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        frame.setFitsSystemWindows(true);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        frame.addView(sv);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(14), dp(24), dp(40));
        sv.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = tv("KEY", 22, INK, BLACK);
        logo.setLetterSpacing(0.22f);
        top.addView(logo, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView plus = tv("+", 26, 0xFFFFFFFF, BLACK);
        plus.setGravity(Gravity.CENTER);
        plus.setBackground(rr(INK, 22, 0, 0));
        plus.setOnClickListener(v -> togglePanel());
        top.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        root.addView(top);

        cb = new ConnectButton(this);
        root.addView(cb, lp(MATCH, dp(310), 0, 6, 0, 0));
        cb.setOnClickListener(v -> {
            cb.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);
            if (uiState != ConnectButton.CONNECTING) toggle();
        });

        tvState = tv("OFF", 46, INK, BLACK);
        tvState.setLetterSpacing(0.04f);
        tvState.setGravity(Gravity.CENTER);
        root.addView(tvState, lp(MATCH, WRAP, 0, 0, 0, 0));
        sub = tv("", 14, MUTED, MED);
        sub.setGravity(Gravity.CENTER);
        sub.setOnLongClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("log", SbService.logText() + SbService.error));
            toast("Журнал скопирован");
            return true;
        });
        root.addView(sub, lp(MATCH, WRAP, 0, 2, 0, 0));
        pingView = tv("", 15, MUTED, BLACK);
        pingView.setGravity(Gravity.CENTER);
        root.addView(pingView, lp(MATCH, WRAP, 0, 8, 0, 0));
        timer = tv("00:00:00", 16, GREEN, BLACK);
        timer.setTypeface(Typeface.create("monospace", Typeface.BOLD));
        timer.setGravity(Gravity.CENTER);
        timer.setAlpha(0f);
        root.addView(timer, lp(MATCH, WRAP, 0, 6, 0, 28));

        addPanel = new LinearLayout(this);
        addPanel.setOrientation(LinearLayout.VERTICAL);
        addPanel.setPadding(dp(16), dp(16), dp(16), dp(16));
        addPanel.setBackground(rr(CARD, 20, 0, 0));
        addPanel.setVisibility(View.GONE);
        etIn = new EditText(this);
        etIn.setHint("Вставь ключ, ссылку подписки или ссылку Happ");
        etIn.setTextColor(INK);
        etIn.setHintTextColor(0xFFA9A9A2);
        etIn.setTypeface(Typeface.create(MED, Typeface.NORMAL));
        etIn.setTextSize(14);
        etIn.setMinLines(4);
        etIn.setGravity(Gravity.TOP);
        etIn.setPadding(dp(14), dp(12), dp(14), dp(12));
        etIn.setBackground(rr(BG, 14, 0, 0));
        addPanel.addView(etIn);
        LinearLayout row = new LinearLayout(this);
        TextView paste = tv("Вставить", 14, INK, BLACK);
        paste.setGravity(Gravity.CENTER);
        paste.setPadding(0, dp(14), 0, dp(14));
        paste.setBackground(rr(0xFFE9E9E4, 14, 0, 0));
        paste.setOnClickListener(v -> paste());
        btnAdd = tv("Добавить", 14, 0xFFFFFFFF, BLACK);
        btnAdd.setGravity(Gravity.CENTER);
        btnAdd.setPadding(0, dp(14), 0, dp(14));
        btnAdd.setBackground(rr(INK, 14, 0, 0));
        btnAdd.setOnClickListener(v -> addFromInput());
        LinearLayout.LayoutParams p1 = lp(0, WRAP, 0, 10, 5, 0);
        p1.weight = 1f;
        LinearLayout.LayoutParams p2 = lp(0, WRAP, 5, 10, 0, 0);
        p2.weight = 1f;
        row.addView(paste, p1);
        row.addView(btnAdd, p2);
        addPanel.addView(row);
        addPanel.addView(tv("VLESS · VMESS · TROJAN · SS · HY2 · TUIC · WireGuard · SOCKS · подписки · Happ",
                11, MUTED, MED), lp(WRAP, WRAP, 0, 12, 0, 0));
        root.addView(addPanel, lp(MATCH, WRAP, 0, 0, 0, 20));

        LinearLayout lh = new LinearLayout(this);
        lh.setGravity(Gravity.CENTER_VERTICAL);
        listLabel = tv("", 12, MUTED, BLACK);
        listLabel.setLetterSpacing(0.16f);
        lh.addView(listLabel, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView pingAll = tv("⟳ ПИНГ", 12, INK, BLACK);
        pingAll.setLetterSpacing(0.12f);
        pingAll.setPadding(dp(12), dp(8), dp(4), dp(8));
        pingAll.setOnClickListener(v -> pingAll());
        lh.addView(pingAll);
        root.addView(lh, lp(MATCH, WRAP, 2, 0, 0, 6));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(frame);
        refresh();
        sub.setText(keyLine());
        updateSelection();
    }

    @Override protected void onResume() { super.onResume(); h.post(tick); }

    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }

    // ---------- добавление ----------
    void togglePanel() {
        if (addPanel.getVisibility() == View.GONE) {
            addPanel.setAlpha(0f);
            addPanel.setTranslationY(-dp(12));
            addPanel.setVisibility(View.VISIBLE);
            addPanel.animate().alpha(1f).translationY(0f).setDuration(240).start();
        } else {
            addPanel.animate().alpha(0f).translationY(-dp(12)).setDuration(180)
                    .withEndAction(() -> addPanel.setVisibility(View.GONE)).start();
        }
    }

    void paste() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0)
            etIn.setText(cm.getPrimaryClip().getItemAt(0).coerceToText(this).toString());
    }

    void addFromInput() {
        final List<KeyParser.Key> found = KeyParser.parse(etIn.getText().toString());
        if (found.isEmpty()) { toast("Не удалось распознать ключ"); return; }
        btnAdd.setText("Загрузка…");
        btnAdd.setEnabled(false);
        new Thread(() -> {
            final List<KeyParser.Key> all = new ArrayList<>();
            String err = null;
            for (KeyParser.Key k : found) {
                if (k.type.equals("SUB")) {
                    try {
                        List<KeyParser.Key> sub = KeyParser.parse(KeyParser.fetch(k.raw));
                        int before = all.size();
                        for (KeyParser.Key s : sub) if (!s.type.equals("SUB") && !s.type.equals("CRYPT")) all.add(s);
                        if (all.size() == before) err = "Подписка пуста или в неподдерживаемом формате";
                    } catch (Exception e) {
                        err = "Подписка не скачалась: " + e.getMessage();
                    }
                } else if (k.type.equals("CRYPT")) {
                    err = "Зашифрованная Happ-ссылка читается только самим Happ. Возьми обычную ссылку подписки (https://…)";
                } else {
                    all.add(k);
                }
            }
            final String fe = err;
            runOnUiThread(() -> {
                int n = store(all);
                btnAdd.setText("Добавить");
                btnAdd.setEnabled(true);
                if (n > 0) {
                    etIn.setText("");
                    toast("Добавлено ключей: " + n);
                    togglePanel();
                    pingAll();
                }
                if (fe != null) toast(fe);
            });
        }).start();
    }

    int store(List<KeyParser.Key> all) {
        int added = 0, first = -1;
        for (KeyParser.Key k : all) {
            boolean dup = false;
            for (int i = 0; i < keys.length(); i++)
                if (keys.optJSONObject(i).optString("c").equals(k.raw)) dup = true;
            if (dup) continue;
            try {
                JSONObject o = new JSONObject();
                o.put("n", k.name);
                o.put("t", k.type);
                o.put("c", k.raw);
                o.put("h", k.host);
                keys.put(o);
                if (first < 0) first = keys.length() - 1;
                added++;
            } catch (Exception e) { }
        }
        if (first >= 0) sel = first;
        save();
        refresh();
        updateSelection();
        return added;
    }

    void save() { sp.edit().putString("keys", keys.toString()).putInt("sel", sel).apply(); }

    void delKey(int i) {
        JSONArray n = new JSONArray();
        for (int j = 0; j < keys.length(); j++) if (j != i) n.put(keys.opt(j));
        keys = n;
        if (sel >= keys.length()) sel = Math.max(0, keys.length() - 1);
        save();
        refresh();
        updateSelection();
    }

    // ---------- список ----------
    String keyLine() {
        JSONObject o = keys.optJSONObject(sel);
        return o == null ? "Добавь ключ, чтобы начать" : o.optString("t") + " · " + o.optString("n");
    }

    void refresh() {
        list.removeAllViews();
        if (sel >= keys.length()) sel = 0;
        listLabel.setText(keys.length() == 0 ? "" : "КЛЮЧИ · " + keys.length());
        if (keys.length() == 0) {
            TextView e = tv("Пока пусто.\nНажми + и вставь любой ключ.", 14, MUTED, MED);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(20), 0, dp(20));
            list.addView(e);
        }
        for (int i = 0; i < keys.length(); i++) {
            View c = makeCard(i);
            c.setAlpha(0f);
            c.setTranslationY(dp(14));
            c.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(i, 10) * 50L).setDuration(260).start();
            list.addView(c);
        }
        styleCards();
        if (uiState == ConnectButton.OFF) sub.setText(keyLine());
    }

    View makeCard(final int i) {
        JSONObject o = keys.optJSONObject(i);
        final String raw = o.optString("c");
        final LinearLayout c = new LinearLayout(this);
        c.setTag(raw);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(dp(16), dp(14), dp(8), dp(14));
        TextView badge = tv(o.optString("t"), 10, 0xFFFFFFFF, BLACK);
        badge.setLetterSpacing(0.08f);
        badge.setPadding(dp(9), dp(5), dp(9), dp(5));
        badge.setBackground(rr(INK, 8, 0, 0));
        c.addView(badge);
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView name = tv(o.optString("n"), 16, INK, BLACK);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        TextView host = tv(o.optString("h"), 12, MUTED, MED);
        host.setSingleLine(true);
        host.setEllipsize(TextUtils.TruncateAt.END);
        mid.addView(name);
        mid.addView(host);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        mp.setMargins(dp(14), 0, dp(8), 0);
        c.addView(mid, mp);
        TextView pg = tv("", 12, MUTED, BLACK);
        Integer cached = pings.get(raw);
        if (cached != null) setPingText(pg, cached); else pg.setText("…");
        c.addView(pg);
        TextView radio = tv("○", 20, MUTED, BLACK);
        radio.setPadding(dp(10), 0, 0, 0);
        c.addView(radio);
        TextView x = tv("✕", 15, MUTED, BLACK);
        x.setPadding(dp(12), dp(10), dp(10), dp(10));
        c.addView(x);

        c.setOnClickListener(v -> {
            sel = i;
            save();
            styleCards();
            if (uiState == ConnectButton.OFF) fade(sub, keyLine());
            updateSelection();
            c.animate().scaleX(1.025f).scaleY(1.025f).setDuration(110)
                    .withEndAction(() -> c.animate().scaleX(1f).scaleY(1f).setDuration(160).start()).start();
        });
        x.setOnClickListener(v -> {
            if (uiState != ConnectButton.OFF && i == sel) { toast("Сначала отключись"); return; }
            c.animate().alpha(0f).translationX(dp(70)).setDuration(220).withEndAction(() -> delKey(i)).start();
        });
        c.setLayoutParams(lp(MATCH, WRAP, 0, 0, 0, 10));
        return c;
    }

    void styleCards() {
        for (int j = 0; j < list.getChildCount(); j++) {
            View v = list.getChildAt(j);
            if (!(v instanceof LinearLayout)) continue;
            boolean s = j == sel;
            v.setBackground(rr(CARD, 18, s ? INK : 0, 2));
            TextView r = (TextView) ((LinearLayout) v).getChildAt(3);
            r.setText(s ? "●" : "○");
            r.setTextColor(s ? INK : MUTED);
        }
    }

    // ---------- пинг ----------
    void setPingText(TextView t, int ms) {
        t.setText(pingShort(ms));
        t.setTextColor(pingColor(ms));
    }

    void showMainPing(int ms) {
        String t = ms == -2 ? "UDP · пинг недоступен" : ms < 0 ? "сервер недоступен" : ms + " ms";
        SpannableString s = new SpannableString("●  " + t);
        s.setSpan(new ForegroundColorSpan(pingColor(ms)), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        pingView.setTextColor(INK);
        pingView.setText(s);
    }

    void updateSelection() {
        JSONObject o = keys.optJSONObject(sel);
        if (o == null) { pingView.setText(""); return; }
        Integer c = pings.get(o.optString("c"));
        if (c != null) showMainPing(c);
        else { pingView.setTextColor(MUTED); pingView.setText("●  …"); }
        pingSelected();
    }

    void pingKey(final String raw, final String type) {
        pool.execute(() -> {
            int ms;
            try {
                String[] ep = SingBoxConfig.endpoint(type, raw);
                if (ep == null) ms = -1;
                else if (ep[2].equals("udp")) ms = -2;
                else ms = Ping.tcp(ep[0], Integer.parseInt(ep[1]), 3000);
            } catch (Exception e) {
                ms = -1;
            }
            final int r = ms;
            runOnUiThread(() -> applyPing(raw, r));
        });
    }

    void pingSelected() {
        JSONObject o = keys.optJSONObject(sel);
        if (o != null) pingKey(o.optString("c"), o.optString("t"));
    }

    void pingAll() {
        for (int i = 0; i < keys.length(); i++) {
            JSONObject o = keys.optJSONObject(i);
            pingKey(o.optString("c"), o.optString("t"));
        }
    }

    void applyPing(String raw, int ms) {
        pings.put(raw, ms);
        for (int j = 0; j < list.getChildCount(); j++) {
            View v = list.getChildAt(j);
            if (raw.equals(v.getTag())) setPingText((TextView) ((LinearLayout) v).getChildAt(2), ms);
        }
        JSONObject o = keys.optJSONObject(sel);
        if (o != null && raw.equals(o.optString("c"))) showMainPing(ms);
    }

    // ---------- состояние ----------
    void fade(final TextView t, final String s) {
        if (t.getText().toString().equals(s)) return;
        t.animate().alpha(0f).setDuration(120).withEndAction(() -> {
            t.setText(s);
            t.animate().alpha(1f).setDuration(180).start();
        }).start();
    }

    void setState(int s, String msg) {
        uiState = s;
        cb.setState(s);
        if (s == ConnectButton.ON) { if (since == 0) since = SystemClock.elapsedRealtime(); } else since = 0;
        fade(tvState, s == ConnectButton.ON ? "ON" : s == ConnectButton.CONNECTING ? "···" : "OFF");
        fade(sub, msg);
        timer.animate().alpha(s == ConnectButton.ON ? 1f : 0f).setDuration(300).start();
    }

    String errText() { return SbService.error.isEmpty() ? "не удалось запустить" : SbService.error; }

    /** Сверяет экран с реальным состоянием службы VPN. */
    void sync() {
        int s = SbService.state;
        if (s == 2 && uiState != ConnectButton.ON) {
            wantOn = true;
            setState(ConnectButton.ON, "Защищено · " + keyLine());
            pingSelected();
        } else if (s == 1 && uiState == ConnectButton.OFF) {
            setState(ConnectButton.CONNECTING, "Подключаюсь…");
        } else if (s == 0) {
            if (uiState == ConnectButton.ON) {
                wantOn = false;
                setState(ConnectButton.OFF, keyLine());
            } else if (uiState == ConnectButton.CONNECTING && !wantOn) {
                setState(ConnectButton.OFF, keyLine());
            } else if (uiState == ConnectButton.CONNECTING && SystemClock.elapsedRealtime() - startedAt > 1500) {
                wantOn = false;
                setState(ConnectButton.OFF, "Ошибка: " + errText());
            }
        }
    }

    void toggle() {
        if (uiState == ConnectButton.ON) { disconnect(); return; }
        JSONObject o = keys.optJSONObject(sel);
        if (o == null) {
            toast("Сначала добавь ключ");
            if (addPanel.getVisibility() == View.GONE) togglePanel();
            return;
        }
        try {
            pendingCfg = SingBoxConfig.build(o.optString("t"), o.optString("c"));
        } catch (Exception e) {
            toast("Ключ не поддерживается: " + e.getMessage());
            return;
        }
        Intent i = VpnService.prepare(this);
        if (i != null) startActivityForResult(i, 1);
        else startVpn();
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req == 1 && res == RESULT_OK) startVpn();
    }

    void startVpn() {
        wantOn = true;
        startedAt = SystemClock.elapsedRealtime();
        setState(ConnectButton.CONNECTING, "Подключаюсь…");
        startService(new Intent(this, SbService.class).putExtra("config", pendingCfg));
    }

    void disconnect() {
        wantOn = false;
        setState(ConnectButton.CONNECTING, "Отключаюсь…");
        startService(new Intent(this, SbService.class).setAction(SbService.ACTION_STOP));
    }
}
