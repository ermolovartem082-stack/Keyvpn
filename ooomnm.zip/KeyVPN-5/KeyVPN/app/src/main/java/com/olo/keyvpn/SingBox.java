package com.olo.keyvpn;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Запускает sing-box (libbox.aar) через reflection: приложение собирается и без AAR,
 * а мелкие различия версий ядра не ломают компиляцию.
 */
final class SingBox {
    static final String PKG = "io.nekohasekai.libbox.";
    static Object box;
    static boolean inited;

    static Class<?> cls(String n) throws Exception { return Class.forName(PKG + n); }

    static synchronized void start(SbService svc, String cfg) throws Exception {
        Class<?> libbox = cls("Libbox");
        if (!inited) {
            String base = svc.getFilesDir().getAbsolutePath(), temp = svc.getCacheDir().getAbsolutePath();
            String[] paths = {base, base, temp};
            for (Method m : libbox.getMethods()) {
                if (!m.getName().equals("setup")) continue;
                Class<?>[] pt = m.getParameterTypes();
                Object[] a = new Object[pt.length];
                int s = 0;
                for (int i = 0; i < pt.length; i++)
                    a[i] = pt[i] == String.class ? paths[Math.min(s++, 2)] : (pt[i] == boolean.class ? Boolean.FALSE : null);
                m.invoke(null, a);
                break;
            }
            inited = true;
        }
        Class<?> pi = cls("PlatformInterface");
        Object platform = Proxy.newProxyInstance(pi.getClassLoader(), new Class<?>[]{pi}, new H(svc));
        Method ns = null;
        for (Method m : libbox.getMethods()) if (m.getName().equals("newService")) ns = m;
        if (ns == null) throw new NoSuchMethodException("Libbox.newService");
        Object b = ns.invoke(null, cfg, platform);
        try {
            b.getClass().getMethod("start").invoke(b);
        } catch (Throwable t) {
            try { b.getClass().getMethod("close").invoke(b); } catch (Throwable ignored) { }
            throw t instanceof InvocationTargetException ? (Exception) t : new Exception(t);
        }
        box = b;
    }

    static synchronized void stop() {
        if (box == null) return;
        try { box.getClass().getMethod("close").invoke(box); } catch (Throwable ignored) { }
        box = null;
    }

    static String msg(Throwable t) {
        while (t instanceof InvocationTargetException && t.getCause() != null) t = t.getCause();
        if (t instanceof ClassNotFoundException)
            return "в приложении нет ядра sing-box (libbox.aar). Собери APK через GitHub Actions";
        String m = t.getMessage();
        return m == null || m.isEmpty() ? t.getClass().getSimpleName() : m;
    }

    static Object dflt(Class<?> t) {
        if (t == boolean.class) return Boolean.FALSE;
        if (t == int.class) return 0;
        if (t == long.class) return 0L;
        if (t == short.class) return (short) 0;
        if (t == byte.class) return (byte) 0;
        if (t == float.class) return 0f;
        if (t == double.class) return 0d;
        if (t == String.class) return "";
        return null;
    }

    static Object call(Object o, String name) throws Exception {
        for (Method m : o.getClass().getMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == 0) {
                m.setAccessible(true);
                return m.invoke(o);
            }
        }
        throw new NoSuchMethodException(name);
    }

    static void set(Object o, String name, Object v) throws Exception {
        for (Method m : o.getClass().getMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == 1) {
                m.invoke(o, v);
                return;
            }
        }
    }

    static Object iter(Class<?> iface, final List<?> items) {
        return Proxy.newProxyInstance(iface.getClassLoader(), new Class<?>[]{iface}, new InvocationHandler() {
            int i = 0;
            public Object invoke(Object p, Method m, Object[] a) {
                switch (m.getName()) {
                    case "hasNext": return i < items.size();
                    case "next": return i < items.size() ? items.get(i++) : null;
                    default: return dflt(m.getReturnType());
                }
            }
        });
    }

    /** Реализация PlatformInterface: tun через VpnService, остальное по умолчанию. */
    static final class H implements InvocationHandler {
        final SbService svc;
        H(SbService s) { svc = s; }

        public Object invoke(Object proxy, Method m, Object[] a) throws Throwable {
            switch (m.getName()) {
                case "openTun": return svc.openTun(a[0]);
                case "writeLog": SbService.log(String.valueOf(a[0])); return null;
                case "usePlatformInterfaceGetter": return Boolean.TRUE;
                case "getInterfaces": return interfaces();
                case "equals": return proxy == a[0];
                case "hashCode": return System.identityHashCode(proxy);
                case "toString": return "KeyVPN-platform";
                default: return dflt(m.getReturnType());
            }
        }

        Object interfaces() throws Exception {
            Class<?> ni = cls("NetworkInterface"), nii = cls("NetworkInterfaceIterator"), si = cls("StringIterator");
            List<Object> out = new ArrayList<>();
            try {
                for (java.net.NetworkInterface n : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
                    Object o = ni.getConstructor().newInstance();
                    set(o, "setIndex", n.getIndex());
                    set(o, "setMTU", n.getMTU());
                    set(o, "setName", n.getName());
                    List<String> addrs = new ArrayList<>();
                    for (java.net.InterfaceAddress ia : n.getInterfaceAddresses()) {
                        String h = ia.getAddress().getHostAddress();
                        int pct = h.indexOf('%');
                        if (pct > 0) h = h.substring(0, pct);
                        addrs.add(h + "/" + ia.getNetworkPrefixLength());
                    }
                    set(o, "setAddresses", iter(si, addrs));
                    out.add(o);
                }
            } catch (Exception ignored) { }
            return iter(nii, out);
        }
    }
}
