package com.olo.keyvpn;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/** Минимальная запись JSON без зависимостей. */
final class Json {
    static String write(Object o) {
        StringBuilder b = new StringBuilder();
        w(b, o);
        return b.toString();
    }

    @SuppressWarnings("unchecked")
    static void w(StringBuilder b, Object o) {
        if (o == null) b.append("null");
        else if (o instanceof String) str(b, (String) o);
        else if (o instanceof Boolean || o instanceof Number) b.append(o);
        else if (o instanceof Map) {
            b.append('{');
            boolean first = true;
            for (Map.Entry<String, Object> e : ((Map<String, Object>) o).entrySet()) {
                if (!first) b.append(',');
                first = false;
                str(b, e.getKey());
                b.append(':');
                w(b, e.getValue());
            }
            b.append('}');
        } else if (o instanceof Collection) {
            b.append('[');
            boolean first = true;
            for (Object x : (Collection<?>) o) {
                if (!first) b.append(',');
                first = false;
                w(b, x);
            }
            b.append(']');
        } else str(b, o.toString());
    }

    static void str(StringBuilder b, String s) {
        b.append('"');
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        b.append('"');
    }

    static Map<String, Object> map() { return new LinkedHashMap<>(); }
}
