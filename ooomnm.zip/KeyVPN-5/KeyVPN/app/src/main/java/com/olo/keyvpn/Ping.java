package com.olo.keyvpn;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** TCP-пинг до сервера: медиана успешных подключений, -1 если сервер недоступен. */
public class Ping {
    public static int tcp(String host, int port, int timeoutMs) {
        try {
            InetAddress a = InetAddress.getByName(host);
            List<Integer> t = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                long s = System.nanoTime();
                try (Socket k = new Socket()) {
                    k.connect(new InetSocketAddress(a, port), timeoutMs);
                } catch (Exception e) {
                    if (i == 0) return -1;
                    continue;
                }
                t.add((int) ((System.nanoTime() - s) / 1000000));
            }
            if (t.isEmpty()) return -1;
            Collections.sort(t);
            return t.get(t.size() / 2);
        } catch (Exception e) {
            return -1;
        }
    }
}
