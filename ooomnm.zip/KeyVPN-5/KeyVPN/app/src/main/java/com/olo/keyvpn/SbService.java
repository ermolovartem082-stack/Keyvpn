package com.olo.keyvpn;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;

public class SbService extends VpnService {
    public static final String ACTION_STOP = "com.olo.keyvpn.STOP";
    static volatile int state = 0;      // 0 выкл, 1 подключение, 2 включён
    static volatile String error = "";
    static final LinkedList<String> LOG = new LinkedList<>();

    static synchronized void log(String s) {
        LOG.add(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + " " + s);
        while (LOG.size() > 60) LOG.removeFirst();
    }

    static synchronized String logText() {
        StringBuilder b = new StringBuilder();
        for (String s : LOG) b.append(s).append('\n');
        return b.toString();
    }

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        if (i != null && ACTION_STOP.equals(i.getAction())) { shutdown(); return START_NOT_STICKY; }
        final String cfg = i == null ? null : i.getStringExtra("config");
        if (cfg == null) { stopSelf(); return START_NOT_STICKY; }
        if (state != 0) return START_NOT_STICKY;
        state = 1;
        error = "";
        new Thread(() -> {
            try {
                SingBox.start(this, cfg);
                state = 2;
            } catch (Throwable t) {
                error = SingBox.msg(t);
                log("Ошибка: " + error);
                SingBox.stop();
                state = 0;
                stopSelf();
            }
        }).start();
        return START_NOT_STICKY;
    }

    void shutdown() {
        SingBox.stop();
        state = 0;
        stopSelf();
    }

    @Override public void onRevoke() { shutdown(); }

    @Override public void onDestroy() {
        SingBox.stop();
        state = 0;
        super.onDestroy();
    }

    /** Вызывается ядром: создаёт системный VPN-интерфейс и отдаёт ему файловый дескриптор. */
    int openTun(Object o) throws Exception {
        Builder b = new Builder();
        b.setSession("Key VPN");
        int mtu = 0;
        try { mtu = ((Number) SingBox.call(o, "getMTU")).intValue(); } catch (Exception ignored) { }
        b.setMtu(mtu > 0 ? mtu : 9000);
        addPrefixes(b, o, "getInet4Address");
        addPrefixes(b, o, "getInet6Address");
        b.addRoute("0.0.0.0", 0);
        b.addRoute("::", 0);
        String dns = "172.19.0.2";
        try {
            String d = (String) SingBox.call(o, "getDNSServerAddress");
            if (d != null && !d.isEmpty()) dns = d;
        } catch (Exception ignored) { }
        b.addDnsServer(dns);
        try { b.addDisallowedApplication(getPackageName()); } catch (Exception ignored) { }
        ParcelFileDescriptor pfd = b.establish();
        if (pfd == null) throw new IllegalStateException("VPN не разрешён системой");
        return pfd.detachFd();
    }

    void addPrefixes(Builder b, Object o, String getter) {
        try {
            Object it = SingBox.call(o, getter);
            while ((Boolean) SingBox.call(it, "hasNext")) {
                Object p = SingBox.call(it, "next");
                b.addAddress((String) SingBox.call(p, "address"), ((Number) SingBox.call(p, "prefix")).intValue());
            }
        } catch (Exception ignored) { }
    }
}
