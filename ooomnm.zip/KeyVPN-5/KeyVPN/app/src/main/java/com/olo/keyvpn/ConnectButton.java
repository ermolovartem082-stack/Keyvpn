package com.olo.keyvpn;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;

/** Большая чёрная круглая кнопка: тень в покое, зелёное свечение и волны при подключении. */
public class ConnectButton extends View {
    public static final int OFF = 0, CONNECTING = 1, ON = 2;
    static final int R_OFF = 0xFF2C2C2C, R_CON = 0xFF6B6B6B, R_ON = 0xFF00C781, I_OFF = 0xFFEDEDED, I_CON = 0xFFBDBDBD;

    int state = OFF, ring = R_OFF, icon = I_OFF;
    float t, scale = 1f, glow = 0f;
    boolean pressed;
    final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG), ringP = new Paint(Paint.ANTI_ALIAS_FLAG),
            iconP = new Paint(Paint.ANTI_ALIAS_FLAG), rip = new Paint(Paint.ANTI_ALIAS_FLAG),
            arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    final ArgbEvaluator ev = new ArgbEvaluator();
    ValueAnimator loop;

    public ConnectButton(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        ringP.setStyle(Paint.Style.STROKE);
        iconP.setStyle(Paint.Style.STROKE);
        iconP.setStrokeCap(Paint.Cap.ROUND);
        rip.setStyle(Paint.Style.STROKE);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
    }

    float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        loop = ValueAnimator.ofFloat(0f, 1f);
        loop.setDuration(2200);
        loop.setRepeatCount(ValueAnimator.INFINITE);
        loop.setInterpolator(new LinearInterpolator());
        loop.addUpdateListener(a -> { t = (float) a.getAnimatedValue(); invalidate(); });
        loop.start();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (loop != null) loop.cancel();
    }

    public void setState(int s) {
        state = s;
        final int toRing = s == ON ? R_ON : s == CONNECTING ? R_CON : R_OFF;
        final int toIcon = s == ON ? R_ON : s == CONNECTING ? I_CON : I_OFF;
        final int fr = ring, fi = icon;
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(450);
        a.addUpdateListener(v -> {
            float f = (float) v.getAnimatedValue();
            ring = (Integer) ev.evaluate(f, fr, toRing);
            icon = (Integer) ev.evaluate(f, fi, toIcon);
            invalidate();
        });
        a.start();
        ValueAnimator g = ValueAnimator.ofFloat(glow, s == ON ? 1f : 0f);
        g.setDuration(500);
        g.addUpdateListener(v -> { glow = (float) v.getAnimatedValue(); invalidate(); });
        g.start();
    }

    @Override protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float R = Math.min(getWidth(), getHeight()) * 0.30f;
        float breath = state == ON ? (float) (1 + 0.01 * Math.sin(t * 2 * Math.PI)) : 1f;
        float r = R * scale * breath;

        if (state == ON) {
            for (int k = 0; k < 3; k++) {
                float p = (t + k / 3f) % 1f;
                rip.setColor(R_ON);
                rip.setAlpha((int) (110 * (1 - p)));
                rip.setStrokeWidth(dp(2));
                c.drawCircle(cx, cy, r * (1.08f + 0.5f * p), rip);
            }
        }
        if (state == CONNECTING) {
            arc.setColor(0xFF0B0B0B);
            arc.setStrokeWidth(dp(4));
            float o = r * 1.18f;
            RectF rect = new RectF(cx - o, cy - o, cx + o, cy + o);
            c.drawArc(rect, t * 720f, 100f, false, arc);
            c.drawArc(rect, t * 720f + 180f, 60f, false, arc);
        }

        body.setShader(new RadialGradient(cx, cy - r * 0.35f, r * 1.3f,
                new int[]{0xFF2B2B2B, 0xFF000000}, null, Shader.TileMode.CLAMP));
        int shadow = (Integer) ev.evaluate(glow, 0x40000000, 0xAA00C781);
        body.setShadowLayer(dp(22) + dp(14) * glow, 0, dp(10) * (1 - glow), shadow);
        c.drawCircle(cx, cy, r, body);

        ringP.setColor(ring);
        ringP.setStrokeWidth(dp(4));
        c.drawCircle(cx, cy, r - dp(2), ringP);

        float ir = r * 0.34f;
        iconP.setColor(icon);
        iconP.setStrokeWidth(dp(6));
        c.drawArc(new RectF(cx - ir, cy - ir, cx + ir, cy + ir), -55f, 290f, false, iconP);
        c.drawLine(cx, cy - ir * 1.2f, cx, cy - ir * 0.1f, iconP);
    }

    void animScale(float to, Interpolator ip) {
        ValueAnimator a = ValueAnimator.ofFloat(scale, to);
        a.setDuration(to < 1f ? 110 : 380);
        a.setInterpolator(ip);
        a.addUpdateListener(v -> { scale = (float) v.getAnimatedValue(); invalidate(); });
        a.start();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float lim = Math.min(getWidth(), getHeight()) * 0.30f * 1.4f;
        boolean inside = Math.hypot(e.getX() - cx, e.getY() - cy) <= lim;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!inside) return false;
                pressed = true;
                animScale(0.92f, new DecelerateInterpolator());
                return true;
            case MotionEvent.ACTION_UP:
                if (pressed) {
                    pressed = false;
                    animScale(1f, new OvershootInterpolator(3f));
                    if (inside) performClick();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                pressed = false;
                animScale(1f, new DecelerateInterpolator());
                return true;
        }
        return true;
    }

    @Override public boolean performClick() { return super.performClick(); }
}
