package io.nekohasekai.sfa.compose.screen.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import io.nekohasekai.sfa.constant.Status

/**
 * Большая чёрная кнопка запуска + кнопка ввода ключа.
 */
@Composable
fun PowerHero(
    status: Status,
    hasProfile: Boolean,
    onPower: () -> Unit,
    onPasteKey: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ringColor = when (status) {
        Status.Started -> Color(0xFF00C781)
        Status.Stopped -> Color(0xFF3A3A3A)
        else -> Color(0xFFFFB020)
    }
    val label = when (status) {
        Status.Started -> "Подключено"
        Status.Starting -> "Подключение…"
        Status.Stopping -> "Отключение…"
        else -> if (hasProfile) "Нажмите для подключения" else "Сначала добавьте ключ"
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 32.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Box(
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape)
                .background(Color.Black)
                .border(BorderStroke(6.dp, ringColor), CircleShape)
                .clickable(enabled = status != Status.Stopping, onClick = onPower),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Default.PowerSettingsNew,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(88.dp),
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
        )
        OutlinedButton(onClick = onPasteKey) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
            Text(text = "  Вставить ключ")
        }
    }
}
