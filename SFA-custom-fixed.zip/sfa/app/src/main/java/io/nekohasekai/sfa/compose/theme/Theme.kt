package io.nekohasekai.sfa.compose.theme

import android.app.Activity
import android.content.res.Configuration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.core.view.WindowCompat

private val Ink = Color(0xFF0B0B0B)

// Минимализм: белый фон, чёрные акценты, одна светлая серая поверхность для карточек
private val KeyColorScheme =
    lightColorScheme(
        primary = Ink,
        onPrimary = Color.White,
        primaryContainer = Ink,
        onPrimaryContainer = Color.White,
        secondary = Color(0xFF3A3A3A),
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFEDEDEA),
        onSecondaryContainer = Ink,
        tertiary = Color(0xFF00C781),
        background = Color.White,
        onBackground = Ink,
        surface = Color.White,
        onSurface = Ink,
        surfaceVariant = Color(0xFFF1F1EE),
        onSurfaceVariant = Color(0xFF55554F),
        surfaceContainerLowest = Color.White,
        surfaceContainerLow = Color(0xFFF8F8F6),
        surfaceContainer = Color(0xFFF3F3F0),
        surfaceContainerHigh = Color(0xFFEDEDEA),
        surfaceContainerHighest = Color(0xFFE7E7E3),
        outline = Color(0xFF8B8B85),
        outlineVariant = Color(0xFFD9D9D4),
    )


// Тёмно-зелёная схема с лаймовым акцентом
private val KeyDarkColorScheme =
    darkColorScheme(
        primary = Color(0xFFB4DD3A),
        onPrimary = Color(0xFF10200A),
        primaryContainer = Color(0xFF2E3D1C),
        onPrimaryContainer = Color(0xFFC4EA4C),
        secondary = Color(0xFF8FB39E),
        onSecondary = Color(0xFF0A130E),
        secondaryContainer = Color(0xFF1B3128),
        onSecondaryContainer = Color(0xFFBFD8C9),
        tertiary = Color(0xFFB4DD3A),
        background = Color(0xFF0A130E),
        onBackground = Color(0xFFE4F2EA),
        surface = Color(0xFF0A130E),
        onSurface = Color(0xFFE4F2EA),
        surfaceVariant = Color(0xFF14241C),
        onSurfaceVariant = Color(0xFF6F9381),
        surfaceContainerLowest = Color(0xFF08100B),
        surfaceContainerLow = Color(0xFF0E1A13),
        surfaceContainer = Color(0xFF122119),
        surfaceContainerHigh = Color(0xFF182B20),
        surfaceContainerHighest = Color(0xFF1E3527),
        outline = Color(0xFF2F4A38),
        outlineVariant = Color(0xFF223629),
    )

// Жирные заголовки (Roboto Black / ExtraBold)
private val BoldTypography =
    Typography.copy(
        headlineLarge = Typography.headlineLarge.copy(fontWeight = FontWeight.Black),
        headlineMedium = Typography.headlineMedium.copy(fontWeight = FontWeight.Black),
        headlineSmall = Typography.headlineSmall.copy(fontWeight = FontWeight.Black),
        titleLarge = Typography.titleLarge.copy(fontWeight = FontWeight.Black),
        titleMedium = Typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
        titleSmall = Typography.titleSmall.copy(fontWeight = FontWeight.ExtraBold),
        labelLarge = Typography.labelLarge.copy(fontWeight = FontWeight.ExtraBold),
    )

@Composable
fun Theme(
    // По умолчанию берётся значение переключателя темы (ThemeState)
    darkTheme: Boolean = ThemeState.isDark,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    // Подменяем ночной режим в конфигурации, чтобы все места с isSystemInDarkTheme()
    // тоже подчинялись переключателю, а не системной теме.
    val baseConfiguration = LocalConfiguration.current
    val themedConfiguration =
        remember(baseConfiguration, darkTheme) {
            Configuration(baseConfiguration).apply {
                uiMode =
                    (uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
                    if (darkTheme) Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO
            }
        }

    CompositionLocalProvider(LocalConfiguration provides themedConfiguration) {
        MaterialTheme(
            colorScheme = if (darkTheme) KeyDarkColorScheme else KeyColorScheme,
            typography = BoldTypography,
            shapes = Shapes,
            content = content,
        )
    }
}
