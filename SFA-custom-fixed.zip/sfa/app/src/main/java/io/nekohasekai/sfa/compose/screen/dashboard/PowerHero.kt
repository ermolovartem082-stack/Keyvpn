package io.nekohasekai.sfa.compose.screen.dashboard

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import io.nekohasekai.sfa.constant.Status
import kotlinx.coroutines.delay

/**
 * Большая кнопка запуска в стиле тёмно-зелёного оформления:
 * внешнее кольцо + внутренний круг. Выключено: приглушённый значок питания.
 * Подключено: значок плавно превращается в «паузу», кольцо и палки становятся яркими.
 * Под кнопкой таймер работы. Сверху справа переключатель темы.
 */
@Composable
fun PowerHero(
    status: Status,
    hasProfile: Boolean,
    startTime: Long?,
    darkTheme: Boolean,
    onPower: () -> Unit,
    onPasteKey: () -> Unit,
    onToggleTheme: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val isOn = status != Status.Stopped
    val scheme = MaterialTheme.colorScheme

    val ringColor by animateColorAsState(
        targetValue = if (isOn) scheme.primary else scheme.outline,
        animationSpec = tween(500),
        label = "ring",
    )
    val iconColor by animateColorAsState(
        targetValue = if (isOn) scheme.primary else scheme.onSurfaceVariant,
        animationSpec = tween(500),
        label = "icon",
    )

    val label = when (status) {
        Status.Started -> "Подключено"
        Status.Starting -> "Подключение…"
        Status.Stopping -> "Отключение…"
        else -> if (hasProfile) "Нажмите для подключения" else "Сначала добавьте ключ"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 4.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            IconButton(onClick = onToggleTheme) {
                Icon(
                    imageVector = if (darkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                    contentDescription = if (darkTheme) "Светлая тема" else "Тёмная тема",
                    tint = scheme.onSurfaceVariant,
                )
            }
        }

        // Внешнее кольцо
        Box(
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape)
                .background(scheme.surfaceContainerHigh)
                .border(BorderStroke(3.dp, ringColor), CircleShape)
                .clickable(enabled = status != Status.Stopping, onClick = onPower),
            contentAlignment = Alignment.Center,
        ) {
            // Внутренний круг
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
                    .background(scheme.surfaceContainer),
                contentAlignment = Alignment.Center,
            ) {
                // Фиксированный размер и центровка: значок не «уезжает» во время перехода
                Crossfade(
                    targetState = isOn,
                    modifier = Modifier.size(150.dp),
                    animationSpec = tween(400),
                    label = "powerToPause",
                ) { on ->
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (on) {
                            PauseGlyph(color = iconColor)
                        } else {
                            Icon(
                                imageVector = Icons.Default.PowerSettingsNew,
                                contentDescription = label,
                                tint = iconColor,
                                modifier = Modifier.size(64.dp),
                            )
                        }
                    }
                }
            }
        }

        if (status == Status.Started && startTime != null) {
            ConnectionTimer(startTime = startTime)
        }
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            color = if (isOn) scheme.onSurface else scheme.onSurfaceVariant,
        )
        Button(
            onClick = onPasteKey,
            shape = RoundedCornerShape(22.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = scheme.primaryContainer,
                contentColor = scheme.onPrimaryContainer,
            ),
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
            Text(text = "  Добавить ключ")
        }
    }
}

/** Две вертикальные палки посередине, как значок паузы (цвет задаёт вызывающий). */
@Composable
private fun PauseGlyph(color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        repeat(2) {
            Box(
                modifier = Modifier
                    .size(width = 16.dp, height = 56.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(color),
            )
        }
    }
}

/** Таймер работы подключения ЧЧ:ММ:СС. */
@Composable
private fun ConnectionTimer(startTime: Long) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(startTime) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val total = ((now - startTime) / 1000).coerceAtLeast(0)
    Text(
        text = String.format("%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60),
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Black,
    )
}
